   <header>
       <div class="main wrap">
       		<h1><a href="index.html"><img src="images/logo.png" alt=""></a></h1> 
            <p>Ettumanoor, Kottayam <span>0481 2536575</span></p>
       </div>
       <nav>  
          <ul class="menu">
              <li class="current"><a href="home.php" class="home"><img src="images/home.jpg" alt=""></a></li>
              <li><a href="about.php">About</a></li>
              <li><a href="adminlogin.php">Admin</a></li>
              <li><a href="userlogin.php">User</a></li>
              <li><a href="signup.php">Sign Up</a></li>
              <li><a href="pricelist.php">Price List</a></li>
              <li><a href="news.php">News</a></li>
              <li><a href="search.php">Search</a></li>
              <li><a href="contactus.php">Contact Us</a></li>
          </ul>
          <div class="clear"></div>
        </nav>
   </header>

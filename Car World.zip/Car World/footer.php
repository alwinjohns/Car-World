    <footer>All copy rights to Kottayam CAR World <a href="home.php" target="new">www.ktmcarworld.com</a>. | Kottayam Tuors and Travels :<a href="http://www.ktmtandts.com/" target="new">www.ktmtandts.com</a>, Experiance the change.<br>
        Website Template designed by <a href="http://www.saata.com/" target="new">www.saata.com</a>, the Smart Choice.<br>
    </footer>	
</div> 
</body>
</html>
